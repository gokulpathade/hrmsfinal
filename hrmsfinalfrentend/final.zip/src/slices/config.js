const config = {
    //  serverURL: 'http://172.25.10.216:4000',
    serverURL: 'http://192.168.155.166:4000',
    }
    
    export default config
    